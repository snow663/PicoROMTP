//--------------------------------------------------------------------------------------
// File:    TPPluginSample.cpp
// Desc:    This file implements the plugin-in class that is necessary
//          for a sample TunerPro RT plug-in DLL. This sample module is used by
//          TunerPro to gain access to information about the plug-in and get access to
//          the components that the plug-in DLL implements. Beyond that, it does
//          nothing interesting, but can be used as a base-line for your own plug-in, or
//          as an educational example of the plug-in architecture.
//
//          Each plug-in DLL will implement only one of these modules, although a module
//          can implement many components.
//
//          Documentation should have been distributed with the TunerPro Developer SDK.
//          Also make sure to study ITPPlugin.h for more information on the plug-in
//          architecture.
//
// Copyright (c) Mark Mansur. All rights reserved. This source code is *not*
// redistributable, and may be obtained only by permission from its author, Mark Mansur.
// For information, please see www.tunerpro.net, or contact mark@tunerpro.net.
//--------------------------------------------------------------------------------------
#include "stdafx.h"             // Precompiled header
#include "TPPluginSample.h"     // Contains the declarations for everything we implement in this file

// Our global instantiation of the plug-in object.
TPSamplePlugin    g_plugin;
TPEmulationDriver g_emuDriver;
TPDataAcqIODriver g_dataAcqDriver;

/////////////////////////////////////////////////////////////////////////
// Extern "C" functions that each plug-in must implement and export in
// order to be recognized as a plug-in by TunerPro.
//
// TunerPro will look for these exports when mounting your plug-in DLL. It
// will then instantiate the plug-in object via TPCreatePlugin, and use the
// returned interface to get information on and access the components that you
// create.
//
// These are the only two functions exported by the DLL.

// Plugin factory function
//extern "C" ITPPlugin* TPCreatePlugin();

// Plugin cleanup function
//extern "C" void TPReleasePlugin(ITPPlugin* p_plugin);

//---------------------------------------------------------------------------------------
//  These are the only two functions that are exported by the DLL.
//---------------------------------------------------------------------------------------
extern "C"
{
    // Plugin factory function. TunerPro will call this to instantiate your plug-in
    // module (TPSamplePlugin, in this case).
    __declspec(dllexport) ITPPlugin* TPCreatePlugin()
    {
        // Return the pointer to the global plug-in object. Alternately, you could
        // simply:
        // return new TPSamplePlugin;
        return &g_plugin;
    }

    // Plugin cleanup function. TunerPro will call this when it is done with your
    // plug-in. By the time this is called, TunerPro will have released all components
    // from your plug-in.
    __declspec(dllexport) void TPReleasePlugin(ITPPlugin* pPlugin)
    {
        // Nothing to do here, since the plug-in object isn't on the heap. If you
        // instantiated the plug-in object with new, you'd call delete here. E.g.
        // delete pPlugin;
    }
}



//---------------------------------------------------------------------------------------
//  The base plug-in implementation
//---------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------
// Construction/Destruction
//---------------------------------------------------------------------------------------
TPSamplePlugin::TPSamplePlugin()
{
    // TODO: initialize your member variables here as necessary.
}

TPSamplePlugin::~TPSamplePlugin()
{
    // TODO: cleanup any memory that your object may have allocated, etc.
}

//---------------------------------------------------------------------------------------
// Func: GetPluginInfo
// Desc: Called by TunerPro when the plug-in is loaded. TunerPro uses this information 
//       to inform the user about the plug-in, and to determine its properties.
//---------------------------------------------------------------------------------------
BOOL TPSamplePlugin::GetPluginInfo(TPP_PLUGININFO* pInfoStruct)
{
    if ( pInfoStruct )
    {
        pInfoStruct->dwContractVersion = TPPLUGIN_CONTRACT_VERSION;
        UuidFromString((RPC_CSTR)PLUGIN_GUID, &pInfoStruct->ID);
        StringCchCopy(pInfoStruct->strName, TPP_MAX_NAME,
            TEXT("TunerPro Sample Plug-in"));
        StringCchCopy(pInfoStruct->strDesc, TPP_MAX_DESC,
            TEXT("This plug-in shows you how to write a basic TunerPro plug-in."));
        StringCchCopy(pInfoStruct->strVersion, TPP_MAX_VERSION,
            TEXT("1.0.0"));
        StringCchCopy(pInfoStruct->strAuthor, TPP_MAX_AUTHOR,
            TEXT("Mark Mansur (www.tunerpro.net)"));
        pInfoStruct->dwComponentCount   = TP_COMPONENT_COUNT;
        pInfoStruct->bConfigurable      = TRUE;
        pInfoStruct->wVersionMajor      = 1;
        pInfoStruct->wVersionMinor      = 0;
        return TRUE;
    }
    return FALSE;
}

//--------------------------------------------------------------------------------------
// Func: Configure
// Desc: This may be called from the TunerPro preferences UI, via user interaction. If
//       the plug-in can be globally configured, then respond to GetPluginInfo with 
//       TPP_PLUGININFO::bCongiruable to TRUE, otherwise FALSE.
//--------------------------------------------------------------------------------------
HRESULT TPSamplePlugin::Configure(TPP_CONFIGINFO* pConfigInfo)
{
    if ( pConfigInfo )
    {
        // TODO: Add configuration code (display a UI to allow the user to configure
        // the overall plug-in. Plug-in is responsible for saving configuration and loading
        // it when TunerPro loads the plug-in).
        MessageBox(pConfigInfo->hwndOwner, "User wants to configure the plug-in DLL!",
            "Plug-in Configuration Requested", MB_ICONINFORMATION);
    }
    return S_OK;
}

//--------------------------------------------------------------------------------------
// Func: GetComponent
// Desc: This is how the app gets access to the components implemented in the plug-in
//       DLL. 
//--------------------------------------------------------------------------------------
ITPPluginComponent* TPSamplePlugin::GetComponent(UINT uiIndex)
{
    // The component-to-index mapping is up to you, the plug-in/component
    // author. When adding components to your plug-in, make sure that they're
    // added here so that TunerPro can access them. Also make sure to increment
    // TPP_PLUGININFO::dwComponentCount, returned in GetPluginInfo.
    //
    // It is up to you, the author, to implement the instantiation of these as you see 
    // fit. You can reference count them, instantiate a new object each time, set them, 
    // up as singletons (which we're doing here), etc.
    switch ( uiIndex )
    {
    case TP_SAMPLE_EMU_DRIVER:
        return &g_emuDriver;
    case TP_SAMPLE_DATAACQIO_DRIVER:
        return &g_dataAcqDriver;

    default:
        goto Exit;
    }

Exit:
    return NULL;
}

//---------------------------------------------------------------------------------------
// Func: ReleaseComponent
// Desc: TunerPro will call this to release a component that was previously sent to it
//       via GetComponent.
//---------------------------------------------------------------------------------------
VOID TPSamplePlugin::ReleaseComponent(ITPPluginComponent* pComponent)
{
    // If you allocaed your component on the stack, you would delete it here. However,
    // we have a single global instance of each of our components, so there's nothing
    // for us to delete.
}

//---------------------------------------------------------------------------------------
// Func: MessageHandler
// Desc: TunerPro can send us messages to notify us of an event, or to request info
//       from us. This also allows TunerPro to extend functionality without breaking the
//       plug-in interface.
//---------------------------------------------------------------------------------------
LONG_PTR TPSamplePlugin::MessageHandler(UINT uiMsg, LPARAM lParam1, LPARAM lParam2)
{
    switch ( uiMsg )
    {
        // TunerPro will send us this message to register its ITunerProApp
        // interface with us. We can use this interface to gain access to any
        // application interfaces it exposes.
    case TPM_REGISTER_TUNERPRO_INTERFACE:
        m_pITunerPro = (ITunerProApp*)lParam1;
        break;
    }
    return 0;
}