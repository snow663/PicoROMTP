//--------------------------------------------------------------------------------------
// File:    TPPluginSample.h
// Desc:    This header file defines all of the objects and components that we'll
//          implement in a sample TunerPro RT plug-in DLL. This sample plug-in does
//          nothing interesting, but can be used as a base-line for your own plug-in, 
//          or as an educational example of the plug-in architecture.
//
//          Documentation should have been distributed with the TunerPro Developer SDK.
//          Also make sure to study ITPPlugin.h for more information on the plug-in
//          architecture.
//
// Copyright (c) Mark Mansur. All rights reserved. This source code is *not*
// redistributable, and may be obtained only by permission from its author, Mark Mansur.
// For information, please see www.tunerpro.net, or contact mark@tunerpro.net.
//--------------------------------------------------------------------------------------
#pragma once

// TunerPro's plug-in header, which defines everything we need to implement a plug-in
#include "ITPPlugin.h"

//---------------------------------------------------------------------------------------
// Plug-in and Component GUIDs. These are used to identify the plug-in and component to
// TunerPro, so that multiple versions are not loaded simultaneously.
//
// EVERY plug-in and component that you create yourself should use its own set of GUIDs. 
// Do not re-use GUIDs. This is important. In Visual Studio, use the "tools->Create GUID"
// tool to generate a new GUID for every piece of your plug-in.
//---------------------------------------------------------------------------------------
#define PLUGIN_GUID                 "0A343A61-D098-4b63-988E-1B7850F213E0"
#define EMU_COMPONENT_GUID          "B5A2134A-7E5F-47ef-B30A-63BC4370516F"
#define DATAACQIO_COMPONENT_GUID    "960143AD-432B-4f67-8D32-A86E45CD339B"


//---------------------------------------------------------------------------------------
// Globals struct. These are globals to be shared across all CPP files in this project.
//  It's handy to have them live in their own struct as a collection.
//---------------------------------------------------------------------------------------
struct GLOBALS
{
    HMODULE     hModule;
};
extern GLOBALS globals;



//---------------------------------------------------------------------------------------
// Enumeration of indexes of components contained in this plug-in DLL. This is used by
// GetComponent override of ITPPlugin, and is how the plug-in determines which component
// to instantiate and return to TunerPro.
//---------------------------------------------------------------------------------------
enum 
{
    TP_SAMPLE_EMU_DRIVER,
    TP_SAMPLE_DATAACQIO_DRIVER,

    TP_COMPONENT_COUNT,
};



//---------------------------------------------------------------------------------------
//  The base plug-in class. There should only one instance of this object per plug-in
//  DLL.
//---------------------------------------------------------------------------------------
class TPSamplePlugin : public ITPPlugin    
{
public:
    TPSamplePlugin();
    ~TPSamplePlugin();

    //---------------------------------------------------------------------------------------
    // ITPPlugin Methods

    BOOL                GetPluginInfo(TPP_PLUGININFO* pInfoStruct);
    HRESULT             Configure(TPP_CONFIGINFO* pConfigInfo);
    ITPPluginComponent* GetComponent(UINT uiIndex);
    VOID                ReleaseComponent(ITPPluginComponent* pComponent);
    LONG_PTR            MessageHandler(UINT uiMsg, LPARAM lParam1, LPARAM lParam2);

    //---------------------------------------------------------------------------------------
    // TODO: Your own methods (if necessary)

private: // variables, etc

    ITunerProApp*   m_pITunerPro;       // TunerPro's app interface
};



//---------------------------------------------------------------------------------------
//  A sample emulation component class. Your plug-in may have one, many, or perhaps no
//  emulation component.
//---------------------------------------------------------------------------------------
class TPEmulationDriver : public ITPEmulator
{
public:

    TPEmulationDriver();
    ~TPEmulationDriver();

    //---------------------------------------------------------------------------------------
    // ITPPluginComponent Methods

    inline TPPCOMPONENT_TYPE GetType()       { return TPPLUGINCOMPONENT_EMULATION_DRIVER; }
    BOOL        GetComponentInfo(IN OUT TPP_COMPONENTINFO* pInfoStruct);
    HRESULT     Configure(TPP_CONFIGINFO* pConfigInfo);
    LONG_PTR    MessageHandler(UINT uiMsg, LPARAM lParam1, LPARAM lParam2);
    const CHAR* GetLastErrorText(BOOL& bPrompt);

    //---------------------------------------------------------------------------------------
    // ITPEmulator Methods

    HRESULT     GetHardwareInfo(TPEMUCAPS* pCaps);
    HRESULT     InitializeHardware();
    HRESULT     ReleaseHardware();

    HRESULT     CancelOperation();

    HRESULT     GetBank(UINT* puiBank);
    HRESULT     SetBank(UINT uiBank);
    HRESULT     GetCurrentBankSize(UINT* puiSize);

    HRESULT     GetJustificationOffset(UINT bcData, UINT* puiOffset);

    HRESULT     WriteData(TPEMUWRITE* pWriteInfo);
    HRESULT     ReadData(TPEMUREAD* pReadInfo);
    HRESULT     VerifyData(TPEMUVERIFY* pVerifyInfo);
    HRESULT		BeginTrace(TPTRACEINIT* pTraceInit);
    BOOL		IsTracing();
    HRESULT		EndTrace();

    //---------------------------------------------------------------------------------------
    // TODO: Your own methods (if necessary)

private: // Vars

    CHAR        m_strLastError[300];    // If an error occurs while doing work in our component, we store it here
    BOOL        m_bErrorPrompt;         // Should the last error be bubbled up to the user?
};



//---------------------------------------------------------------------------------------
// A sample data acquisition component class. Your plug-in may have one, many, or perhaps
// no data acquisition component.
//---------------------------------------------------------------------------------------
class TPDataAcqIODriver : public ITPDataAcqIO
{
public:

    TPDataAcqIODriver();
    ~TPDataAcqIODriver();

    //---------------------------------------------------------------------------------------
    // ITPPluginComponent Methods

    inline TPPCOMPONENT_TYPE GetType()       { return TPPLUGINCOMPONENT_DATAACQIO_DRIVER; }
    BOOL        GetComponentInfo(IN OUT TPP_COMPONENTINFO* pInfoStruct);
    HRESULT     Configure(TPP_CONFIGINFO* pConfigInfo);
    LONG_PTR    MessageHandler(UINT uiMsg, LPARAM lParam1, LPARAM lParam2);
    const CHAR* GetLastErrorText(BOOL& bPrompt);

    //---------------------------------------------------------------------------------------
    // ITPDataAcqIO Methods

    HRESULT GetHardwareInfo(TPDATAACQIOCAPS* pCaps);

    HRESULT InitializeHardware(TPDATAACQHWINIT* pInitStruct);
    HRESULT ReleaseHardware();

    HRESULT WriteData(TPDATAACQWRITE* pWriteInfo);
    HRESULT ReadData(TPDATAACQREAD* pReadInfo);

    HRESULT SetTimeouts(TPDATAACQTIMEOUTS* pTimeoutInfo);
    HRESULT GetTimeouts(TPDATAACQTIMEOUTS* pTimeoutInfo);

    HRESULT PurgeReceiveBuffer();
    HRESULT PurgeTransmitBuffer();

    //---------------------------------------------------------------------------------------
    // TODO: Your own methods (if necessary)

private:

    CHAR        m_strLastError[300];    // If an error occurs while doing work in our component, we store it here
    BOOL        m_bErrorPrompt;         // Should the last error be bubbled up to the user?
};

// It only makes sense to have a single plug-in object and one of each component per-DLL. When TunerPro
// asks us for the interface, we'll return a pointer to these global instantiations. In your own implementation,
// it may make sense to allocate a new object on the heap instead. That's up to you.
extern TPSamplePlugin    g_plugin;
extern TPEmulationDriver g_emuDriver;
extern TPDataAcqIODriver g_dataAcqDriver;