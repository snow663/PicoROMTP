//--------------------------------------------------------------------------------------
// File:    TPSampleEmuComponent.cpp
// Desc:    This file implements a basic emulation driver plug-in component. This
//          component does nothing interesting, but can be used as a base-line for
//          your own implementation.
//
//          Documentation should have been distributed with the TunerPro Developer SDK.
//          Also make sure to study ITPPlugin.h for more information on the plug-in
//          architecture.
//
// Copyright (c) Mark Mansur. All rights reserved. This source code is *not*
// redistributable, and may be obtained only by permission from its author, Mark Mansur.
// For information, please see www.tunerpro.net, or contact mark@tunerpro.net.
//--------------------------------------------------------------------------------------
#include "stdafx.h"             // Pre-compiled header
#include "TPPluginSample.h"     // Contains the declarations for everything we implement in this file
#include "stdlib.h"             // for rand()


//---------------------------------------------------------------------------------------
//                  Preferred Return Values 
//
// All returned HRESULTs should signify failure in a way that would trigger FAILED(hr);
// Similarly, success should trigger SUCCEEDED(hr);. These are what TunerPro will use
// to determine success/failure state when interacting with your component/plug-in.
// 
// S_OK - general success
// E_FAIL - generic failure (try to be more specific, if possible, though)
// E_INVALIDARG - invalid argument was passed in. Most likely TunerPro will simply fail.
// HRESULT_FROM_WIN32(ERROR_NOT_CONNECTED) - The device isn't attached or found
//
//---------------------------------------------------------------------------------------



TPEmulationDriver::TPEmulationDriver()
{
    m_bErrorPrompt      = FALSE;
    m_strLastError[0]   = '\0';
}

TPEmulationDriver::~TPEmulationDriver()
{
    ReleaseHardware();
}

//---------------------------------------------------------------------------------------
// Func: GetComponentInfo
// Desc: Virtual implementation for plugin component. Returns information about this
//       component.
//---------------------------------------------------------------------------------------
BOOL TPEmulationDriver::GetComponentInfo(TPP_COMPONENTINFO* pInfoStruct)
{
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::GetComponentInfo called");

    // TODO: Return real information about your component
    if ( pInfoStruct )
    {
        // Inspect the size of the struct to make sure the TunerPro build that's 
        // using us is not expecting something smaller. Members may be added to the struct,
        // but they'll only be added to the end. This means that TunerPro may pass in 
        // a larger struct than you might populate. This is OK. Only return error
        // if TunerPro's struct is smaller than what you'll populate.
        if (pInfoStruct->cbSize < sizeof(TPP_COMPONENTINFO))
        {
            // Return an error!
        }

        // Identify this component in a unique way for TunerPro
        UuidFromString((RPC_CSTR)EMU_COMPONENT_GUID, &pInfoStruct->ID);

        StringCchCopy(pInfoStruct->strName, TPP_MAX_NAME,
            TEXT("TunerPro Sample Emulator Interface"));
        StringCchCopy(pInfoStruct->strDesc, TPP_MAX_DESC,
            TEXT("This component shows you how to write a basic emulator driver for TunerPro RT."));
        StringCchCopy(pInfoStruct->strVersion, TPP_MAX_VERSION,
            TEXT("1.0.0"));

        // Tell TunerPro to allow the user to configure this component
        pInfoStruct->bConfigurable = TRUE;

        // These fields allow TunerPro to easily determine a version number
        // for comparison. Strings are harder to compare, but easier to read.
        pInfoStruct->wVersionMajor = 1;
        pInfoStruct->wVersionMinor = 0;

        return TRUE;
    }
    return FALSE;
}

//---------------------------------------------------------------------------------------
// Func: Configure
// Desc: Virtual implementation for plugin component. Allows the user to configure the
//       component.
//---------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::Configure(TPP_CONFIGINFO* pConfigInfo)
{
    // TODO: Write code that displays UI for the user to configure this component.
    // If the component is not configurable, tell TunerPro via GetComponentInfo and
    // TPP_COMPONENTINFO::bConfigurable
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::Configure called");
    if ( pConfigInfo )
    {
        // Inspect the size of the struct to make sure the TunerPro build that's 
        // using us is not expecting something of a different size
        if ( pConfigInfo->cbSize < sizeof(TPP_CONFIGINFO) )
        {
            // Return an error!
        }

        MessageBox(pConfigInfo->hwndOwner, "User wants to configure the emulation driver!",
            "Component Configuration Requested", MB_ICONINFORMATION);
    }
    return S_OK;
}

//---------------------------------------------------------------------------------------
// Func: MessageHandler
// Desc: TunerPro can send us messages to notify us of an event, or to request info
//       from us. This also allows TunerPro to extend functionality without breaking the
//       plug-in interface.
//---------------------------------------------------------------------------------------
LONG_PTR TPEmulationDriver::MessageHandler(UINT uiMsg, LPARAM lParam1, LPARAM lParam2)
{
    switch (uiMsg)
    {
        // TunerPro will send us this message to register its ITunerProApp
        // interface with us. We can use this interface to gain access to any
        // application interfaces it exposes.
        case TPM_REGISTER_TUNERPRO_INTERFACE:
        {
            // TunerPro sent us its application interface. You generally want to store this off in a global for future
            // use. Here, we'll just save it locally to show you how to get it and use it for sending TunerPro messages
            ITunerProApp* pITunerPro = (ITunerProApp*)lParam1;

            // EXAMPLE: We can use the ITunerProApp interface to (for example) tell TunerPro that the hardware this
            // plug-in manages has been disconnected by the user
            pITunerPro->MessageHandler(TPM_HARDWARE_RELEASED, (LPARAM)this, 0);
        }
        break;

        case TPM_BIN_LOADED:
            // TunerPro is telling us that the user loaded a new bin file. Perhaps we want to reset some state in the emulation hardware.
            break;

        // TODO: handle other to-be-defined messages from TunerPro here
    }
    return 0;
}

//---------------------------------------------------------------------------------------
// Func: GetLastErrorText
// Desc: Virtual implementation for plugin component. TunerPro calls this upon error to
//       determine whether friendly error should be posted to user, and what text to post.
//---------------------------------------------------------------------------------------
const CHAR* TPEmulationDriver::GetLastErrorText(BOOL& bPrompt)
{
    bPrompt = m_bErrorPrompt;

    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::GetLastErrorText called");

    return m_strLastError;
}

//---------------------------------------------------------------------------------------
// Func: GetHardwareInfo
// Desc: Virtual implementation for plugin component. App calls this to gather information
//       on the attached hardware. The caps are used to enable/disable funcitonality
//       within the app.
//---------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::GetHardwareInfo(TPEMUCAPS* pCaps)
{

    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::GetHardwareInfo called");

    // TODO: Return real information about the currently attached hardware
    if ( pCaps )
    {
        // Inspect the size of the struct to make sure the TunerPro build that's 
        // using us is not expecting something of a different size
        if ( pCaps->cbSize < sizeof(TPEMUCAPS) )
        {
            // Return an error!
        }

        // Name, Description and Version strings. Perhaps these are retrieved directly from
        // the hardware.
        StringCchCopy(pCaps->strName, TPP_MAX_NAME, "Cool Hardware!");
        StringCchCopy(pCaps->strDescription, TPP_MAX_DESC, "This is an example description.");
        StringCchCopy(pCaps->strVersion, TPP_MAX_VERSION, "0.1B");

        //
        // Tell TunerPro what the hardware can do. You should perform some logic
        // based on what you know about the attached hardware, and tell TunerPro
        // what it can do.
        //

        
        // if ( we can emulate )
        pCaps->dwCapFlags |= TPP_EMU_CAP_REALTIMEMULATION | TPP_EMU_CAP_CHIPEMULATION;
        // if ( the hardware has more than one bank )
        pCaps->dwCapFlags |= TPP_EMU_CAP_SWBANKSWITCHING;
        // if ( the hardware has an address watch feature )
        pCaps->dwCapFlags |= TPP_EMU_CAP_ADDRESSWATCH;

        // if more than one bank is supported and the bank can be switched by software,
        // be sure to set TPP_EMU_CAP_SWBANKSWITCHING in the caps
        pCaps->uiBankCount = 1;

        // Total memory size of emulation hardware (bank count * bank size, typically)
        pCaps->uiTotalMemorySize = 32 * 1024; // 32KB

        return S_OK;
    }
    else
        return E_INVALIDARG;
}

//--------------------------------------------------------------------------------------
// Func: InitializeHardware
// Desc: Initializes all hardware used by the component. When TunerPro calls this, we
//       must ensure all necessary hardware is available and ready to do work.
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::InitializeHardware()
{
    HRESULT hr = S_OK;

    // TODO: Initialize the hardware, if necessary.
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::InitializeHardware called");

    // For device initialization failure, return error. Preferrably
    // HRESULT_FROM_WIN32(ERROR_NOT_CONNECTED)
    return hr;
}

//--------------------------------------------------------------------------------------
// Func: ReleaseHardware
// Desc: Releases all hardware associated with the plugin. When TunerPro calls this, it
//       means that it's done using the hardware, so ports should be closed, memory
//       cleaned up, etc.
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::ReleaseHardware()
{
    // TODO: release the hardware
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::ReleaseHardware called");

    // Note - do not send TunerPro a TPM_HARDWARE_RELEASED message here. TunerPro is requesting its release,
    // so it already expects the hardware to be released when this method returns.
    return S_OK;
}

//---------------------------------------------------------------------------------------
// Func: CancelOperation
// Desc: Cancels any operation in progress. Returns S_FALSE if no operation is in progress.
//---------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::CancelOperation()
{
    // Called when the user wants to cancel an operation that may be in progress. 
    // TunerPro UI may allow the user to cancel operations.
    
    // TODO: cancel any pending operations with the hardware, if possible. If not possible
    // or no operation is in progress, return S_FALSE, etc.
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::CancelOperation called");

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Func: GetBank
// Desc: Called by TunerPro to retrieve the currently set memory bank of the attached
//       hardware.
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::GetBank(UINT* puiBank)
{
    CHAR chBank = 0;

    // TODO: return the bank currently enabled on the hardware
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::GetBank called");

    if ( puiBank )
        *puiBank = (UINT)chBank;

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Func: SetBank
// Desc: Called by TunerPro to set the current memory bank. We need to do this on both
//       pieces of hardware we may be utilizing.
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::SetBank(UINT uiBank)
{
    HRESULT hr = S_OK;

    // TODO: Set the bank, if software bank selection is supported. If not, return S_OK.
    // If so, select the bank and return success or failure.
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::SetBank called");

    return hr;
}

//--------------------------------------------------------------------------------------
// Func: GetCurrentBankSize
// Desc: Returns the size of the currently selected bank.
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::GetCurrentBankSize(UINT* puiSize)
{
    HRESULT hr = S_OK;
    UINT uiSize = 1024 * 32; // 32KB as an example. Your hardware is probably different.

    // TODO: return the size of the currently selected bank. If your hardware doesn't
    // support banks, you should return the size of device emulation memory.
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::InitializeHardware called");

    if ( puiSize )
        *puiSize = uiSize;
    return hr;
}

//--------------------------------------------------------------------------------------
// Func: GetJustificationOffset
// Desc: TunerPro will call this to determine the base offset to which to upload or
//       download data. Some emulators require that the binary be uploaded to the 
//       highest addresses in RAM (end-justify the data). Others require that the data
//       live at offset 0.
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::GetJustificationOffset(UINT bcData, UINT* puiOffset)
{
    HRESULT hr = S_OK;
    UINT uiOffset = 0;

    // TODO: Tell TunerPro the base offset to which to upload and download data. 
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::GetJustificationOffset called");

    // End justify (tell TunerPro to upload everything to the highest possible portion
    // of hardware RAM, in our 32KB of RAM.


    if ( bcData > (32 * 1024) )
        return HRESULT_FROM_WIN32(ERROR_INVALID_BLOCK_LENGTH);
    else
        uiOffset = 32 * 1024 - bcData;

    if ( puiOffset )
        *puiOffset = uiOffset;
    
    return hr;
}

//--------------------------------------------------------------------------------------
// Func: WriteData
// Desc: TunerPro will call this when the user requests that data be uploaded to the
//       emulator.
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::WriteData(TPEMUWRITE* pWriteInfo)
{
    HRESULT hr = S_OK;

    if ( !pWriteInfo )
        return E_INVALIDARG;

    // TODO: Write data from the hardware and return it to TunerPro
    // As progress is being made, tell TunerPro about it via its progress interface.
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::WriteData called");

    // We need to check to make sure we can use the progress bar. This
    // is good manners.
    HRESULT hrProgLock = E_FAIL;
    if ( pWriteInfo->pIProgress )
        hrProgLock = pWriteInfo->pIProgress->Lock();
    BOOL bUseProgress = (hrProgLock == S_OK);

    if ( pWriteInfo->dwFlags & TPP_EMU_WRITE_RAWDATA )
    {
        // If this flag is specified, we should be writing the 
        // data directly to the port that the emulation is using
        // to communicate. This may be used by TunerPro to pass 
        // data directly to the hardware, and allows you to write
        // ADX files that can send data to the emulator unmolested.

        // For example, if we were using a serial port and already had the
        // port open, we might do something like this to write data directly to
        // the port:

        // WriteFile(m_hSerialPort, pWriteInfo->pData, pWriteInfo->cbData, &dwIO, NULL);
    }
    else
    {
        //
        // Do some pretend work, mimic some progress...
        //

        // Set the range to process 25 "chunks" of work
        if ( bUseProgress )
        {
            pWriteInfo->pIProgress->SetRange(0, 25);
            pWriteInfo->pIProgress->SetCurrentPosition(0);
        }

        for ( UINT ui = 0; ui < 25; ++ui )
        {
            // Pretend work. 25 chunks of 100ms is 2.5 seconds of pretend work.
            Sleep(100);
            
            // Step the progress bar
            if ( bUseProgress )
                pWriteInfo->pIProgress->Step();
        }
    }

    // Reset the progress bar to 0 progress, no text. Finally, unlock the bar.
    if ( bUseProgress )
    {
        pWriteInfo->pIProgress->SetCurrentPosition(0);
        pWriteInfo->pIProgress->SetText(NULL, 0);
        pWriteInfo->pIProgress->Unlock();
    }

    if ( SUCCEEDED(hr) && pWriteInfo->puiTransferred )
        *pWriteInfo->puiTransferred = 32;   // set to the actual bytes transferred
    else if ( FAILED(hr) && pWriteInfo->puiTransferred )
        *pWriteInfo->puiTransferred = 0;

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Func: ReadData
// Desc: TunerPro will call this when the user requests that data be read from the 
//       emulator.
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::ReadData(TPEMUREAD* pReadInfo)
{
    HRESULT hr = S_OK;

    if ( !pReadInfo )
        return E_INVALIDARG;

    // TODO: Read data from the hardware and return it to TunerPro
    // As progress is being made, tell TunerPro about it via its progress interface.
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::ReadData called");

    // We need to check to make sure we can use the progress bar. This
    // is good manners.
    HRESULT hrProgLock = E_FAIL;
    if ( pReadInfo->pIProgress )
        hrProgLock = pReadInfo->pIProgress->Lock();
    BOOL bUseProgress = (hrProgLock == S_OK);

    if ( pReadInfo->dwFlags & TPP_EMU_READ_RAWDATA )
    {
        // If this flag is specified, we should be reading the 
        // data directly from the port that the emulation is using
        // to communicate. This may be used by TunerPro to pass 
        // data directly to the hardware, and allows you to write
        // ADX files that can send data to the emulator unmolested.


        // For example, if we were using a serial port and already had the
        // port open, we might do something like this to read straight from the port:

        // ReadFile(m_hSerialPort, pReadInfo->pBuffer, pReadInfo->cbReadSize, &dwIO, NULL);
    }
    else
    {
        //
        // Do some pretend work, mimic some progress...
        //

        // Set the range to process 25 "chunks" of work
        if ( bUseProgress )
        {
            pReadInfo->pIProgress->SetRange(0, 25);
            pReadInfo->pIProgress->SetCurrentPosition(0);
        }

        for ( UINT ui = 0; ui < 25; ++ui )
        {
            // Pretend work. 25 chunks 100ms is 2.5 seconds of pretend work.
            Sleep(100);

            // Step the progress bar
            if ( bUseProgress )
                pReadInfo->pIProgress->Step();
        }
    }

    // Reset the progress bar to 0 progress, no text. Finally, unlock the bar.
    if ( bUseProgress )
    {
        pReadInfo->pIProgress->SetCurrentPosition(0);
        pReadInfo->pIProgress->SetText(NULL, 0);
        pReadInfo->pIProgress->Unlock();
    }

    if ( SUCCEEDED(hr) && pReadInfo->puiTransferred )
        *pReadInfo->puiTransferred = 32;   // set to the actual bytes transferred
    else if ( FAILED(hr) && pReadInfo->puiTransferred )
        *pReadInfo->puiTransferred = 0;

    return hr;
}

//--------------------------------------------------------------------------------------
// Func: VerifyData
// Desc: Verifies the emulation buffer at the specified address against the passed-in
//       data. TunerPro will call this when the user requests that data be verified.
//       For match, return TRUE.
//       For mismatch, return FALSE.
//       For other failure, return failure HRESULT
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::VerifyData(TPEMUVERIFY* pVerifyInfo)
{
    HRESULT hr = TRUE;  // verification match

    if ( !pVerifyInfo )
        return E_INVALIDARG;

    // TODO: verify the data passed to us by TunerPro against the data
    // in the hardware at the requested address.
    // As progress is being made, tell TunerPro about it via its progress interface.

    // Mimic some progress. For illustration, we'll do 25 "chunks" of work.
    // Work, in this example, is just a 100ms sleep.

    // We need to check to make sure we can use the progress bar. This
    // is good manners.
    HRESULT hrProgLock = E_FAIL;
    if ( pVerifyInfo->pIProgress )
        hrProgLock = pVerifyInfo->pIProgress->Lock();
    BOOL bUseProgress = (hrProgLock == S_OK);

    //
    // Do some work, mimic some progress...
    //

    // Set the range to process 25 "chunks" of work
    if ( bUseProgress )
    {
        pVerifyInfo->pIProgress->SetRange(0, 25);
        pVerifyInfo->pIProgress->SetCurrentPosition(0);
    }

    for ( UINT ui = 0; ui < 25; ++ui )
    {
        Sleep(100); // 25 * 100ms = 2.5 seconds of work

        // Step the progress bar
        if ( bUseProgress )
            pVerifyInfo->pIProgress->Step();
    }

    // Reset the progress bar to 0 progress, no text. Finally, unlock the bar.
    if ( bUseProgress )
    {
        pVerifyInfo->pIProgress->SetCurrentPosition(0);
        pVerifyInfo->pIProgress->SetText(NULL, 0);
        pVerifyInfo->pIProgress->Unlock();
    }

    // For data match, return TRUE (1), for mismatch return FALSE (0).
    // For actual device (or other failure), return failure HRESULT (a negative number).

    // Roll the dice... (perhaps we'll have a match, perhaps it will be a mismatch)
    hr = (HRESULT)rand() % 2;

    return hr;

}

//--------------------------------------------------------------------------------------
// Func: BeginTrace
// Desc: 
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::BeginTrace(TPTRACEINIT* pTraceInit)
{
    HRESULT hr = S_OK;

    if ( !pTraceInit )
        return E_INVALIDARG;

    // Inspect the size of the struct to make sure the TunerPro build that's 
    // using us is not expecting something of a different size
    if ( pTraceInit->cbSize < sizeof(TPTRACEINIT) )
    {
        // Return an error!
    }

    // TODO: start an address watch session on the hardware. This is generally
    // an asynchronous operation on most hardware, and the hardware sill stream hits
    // to the component as they happen. When this happens, TPTRACEINIT::pfnCallback
    // should be called with the relevant information so that TunerPro can process
    // the hit.
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::BeginTrace called");

    return hr;
}

//--------------------------------------------------------------------------------------
// Func: IsTracing
// Desc: 
//--------------------------------------------------------------------------------------
BOOL TPEmulationDriver::IsTracing()
{

    // TODO: Tell TunerPro whether or not the hardware is currently watching
    // for address hits
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::IsTracing called");

    return FALSE;
}

//--------------------------------------------------------------------------------------
// Func: EndTrace
// Desc: 
//--------------------------------------------------------------------------------------
HRESULT TPEmulationDriver::EndTrace()
{
    HRESULT hr = S_OK;

    // TODO: Stop the address watch session, if there is one.
    OutputDebugString("PLUGIN SAMPLE: TPEmulationDriver::EndTrace called");

    return hr;
}