//--------------------------------------------------------------------------------------
// File:    TPMessages.h
// Desc:    Defines all messages, notifications, and parameters that can be sent to 
//          plug-ins and components.
//
//          This header will likely grow over time. Additions to this header in future
//          TunerPro versions will not break released plug-ins.
//
// Copyright (c) Mark Mansur. All rights reserved. This source code is *not*
// redistributable, and may be obtained only by permission from its author, Mark Mansur.
// For information, please see www.tunerpro.net, or contact mark@tunerpro.net.
//--------------------------------------------------------------------------------------
#pragma once
#ifndef _TPMESSAGES_H
#define _TPMESSAGES_H

//
//---------------------------------------------------------------------------------------
// Messages 0-4999 are reserved
//---------------------------------------------------------------------------------------
//

//
// TunerPro is the send of the following:
// 


//---------------------------------------------------------------------------------------
// Message: TPM_REGISTER_TUNERPRO_INTERFACE
// Dir:     TunerPro -> Plug-in
// Desc:    Sent to plug-in object by TunerPro to register the ITunerProApp interface.
// Param1:  ITunerPro* pInterface. The application interface to be registered.
// Param2:  Not used
//---------------------------------------------------------------------------------------
#define TPM_REGISTER_TUNERPRO_INTERFACE     5000L

//---------------------------------------------------------------------------------------
// Message: TPM_BIN_LOADED
// Dir:     TunerPro -> Plug-in
// Desc:    Sent to plug-in object and components by TunerPro to notify that the user
//          has loaded a bin file.
// Param1:  Not used
// Param2:  Not used
//---------------------------------------------------------------------------------------
#define TPM_BIN_LOADED                      5010L

//
// TunerPro can receive the following messages sent from the plug-in
//

//---------------------------------------------------------------------------------------
// Message: TPM_HARDWARE_RELEASED
// Dir:     Plug-in -> TunerPro
// Desc:    Sent to TunerPro from plug-in object and components to notify TunerPro that
//          the hardware the plug-in manages has been disconnected. TunerPro will reset
//          UI state to show hardware is no longer disconnected, re-enable connection
//          button, etc.
// Param1:  ITPPluginComponent* of the sender, i.e. (LPARAM)this
// Param2:  Not used yet
//---------------------------------------------------------------------------------------
#define TPM_HARDWARE_RELEASED               7000L

#endif // _TPMESSAGES_H