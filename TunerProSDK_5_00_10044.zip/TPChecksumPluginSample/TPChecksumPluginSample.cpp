//--------------------------------------------------------------------------------------
// File:    TPChecksumPluginSample.cpp
// Desc:    This file implements a simple checksum plugin-in DLL. It can be used as a
//          base-line for your own plug-in, or as an educational example of the plug-in
//          architecture.
//
//          Documentation should have been distributed with the TunerPro Developer SDK.
//          Also make sure to study ITPPlugin.h for more information on the plug-in
//          architecture.
//
// Copyright (c) Mark Mansur. All rights reserved. This source code is *not*
// redistributable, and may be obtained only by permission from its author, Mark Mansur.
// For information, please see www.tunerpro.net, or contact mark@tunerpro.net.
//--------------------------------------------------------------------------------------

#include "stdafx.h"
#include "rpc.h" // for GUID used for unique identifier
#include "MMChecksumPlugin.h"

// We'll use this to return a meaningful error message to the application upon request
CHAR g_strLastError[1024];

//---------------------------------------------------------------------------------------
// Every checksum plug-in needs to have a unique identifier. This identifier allows
// TunerPro to determine if the plug-in has already been loaded. Every time you create
// a new checksum plug-in DLL, you should create a new GUID to uniquely identify it.
//---------------------------------------------------------------------------------------
#define PLUGIN_GUID     "9A53F577-D1C9-40C6-8691-7A54FA789D3A"

//---------------------------------------------------------------------------------------
// A single checksum plug-in can implement many different types of checksums and checksum
// calculations. This sample will implement 2 different kinds. The application will 
// reference the checksum by index, so we'll define those indexes here.
//---------------------------------------------------------------------------------------
enum 
{
    CHECKSUM_SAMPLE_SIMPLE,
    CHECKSUM_SAMPLE_COMPLEX,
    CHECKSUM_COUNT
};

//
//---------------------------------------------------------------------------------------
//  There are four C functions that need to be exported from the DLL in order for 
//  TunerPro to successfully load and interact with the plug-in DLL. They are:
// 
//  HRESULT MMCSGetChecksumPluginInfo(MMCHECKSUMPLUGININFO* pPluginInfoStruct);
//  HRESULT MMCSGetChecksumInfo(DWORD dwIndex, MMCHECKSUMINFO* pCSInfoStruct);
//  HRESULT MMCSCalculateChecksum(MMCHECKSUMCALC* pCalcInfo);
//  HRESULT MMCSGetLastErrorMessage(CHAR* strTextOut, DWORD cchTextOut);
//
// We'll implement them here. To tell the compiler that we want to export these
// functions from the DLL, they are prefaced with __declspec(dllexport). To tell the
// compiler to treat them as plain C (rather than C++), they're also prefaced with
// extern "C".
//---------------------------------------------------------------------------------------
//

//---------------------------------------------------------------------------------------
// Func: MMCSgetChecksumPluginInfo (Exported)
// Desc: The application will call this function to gather information about the 
//       plug-in module. The application will use the returned info to make use of the
//       plug-in. Some of the info returned by the plug-in may be displayed to the user.
//---------------------------------------------------------------------------------------
extern "C" __declspec(dllexport)
HRESULT MMCSGetChecksumPluginInfo(MMCHECKSUMPLUGININFO* pPluginInfoStruct)
{
    HRESULT hr = S_OK;

    // Clear the last error text
    g_strLastError[0] = '\0';

    // The application will pass in a structure for us to fill in. Let's check the size of
    // the structure the app passed, just to make sure we're on the same version
    if ( !pPluginInfoStruct )
    {
        hr = E_INVALIDARG;
        goto Exit;
    }

    if ( pPluginInfoStruct->cbStructSize != sizeof(MMCHECKSUMPLUGININFO) )
    {
        hr = HRESULT_FROM_WIN32(ERROR_PRODUCT_VERSION);
        goto Exit;
    }

    // Uniquely identify this plug-in DLL
    UuidFromStringA((RPC_CSTR)PLUGIN_GUID, &pPluginInfoStruct->ID);
    // Tell the application what contract version we're implementing
    pPluginInfoStruct->dwContractVersion = MMCS_CONTRACT_VERSION;
    // Tell the application how many checksum types we're implementing
    pPluginInfoStruct->dwChecksumCount = CHECKSUM_COUNT;
    // User friendly version string
    StringCchCopyA(pPluginInfoStruct->strVersion, ARRAYSIZE(pPluginInfoStruct->strVersion),
        "1.0.0");
    // Info about the author
    StringCchCopyA(pPluginInfoStruct->strAuthor, ARRAYSIZE(pPluginInfoStruct->strAuthor),
        "Mark Mansur (www.tunerpro.net)");
    // User-friendly name of the module
    StringCchCopyA(pPluginInfoStruct->strName, ARRAYSIZE(pPluginInfoStruct->strName),
        "Sample TunerPro Checksum Plug-in");
    // User-friendly description of the module
    StringCchCopyA(pPluginInfoStruct->strDesc, ARRAYSIZE(pPluginInfoStruct->strDesc),
        "This plug-in provides an implementation example, showing how easy it is to create a checksum plug-in.");

Exit:
    return hr;
}



//---------------------------------------------------------------------------------------
// Func: MMCSGetChecksumInfo (Exported)
// Desc: 
//---------------------------------------------------------------------------------------
extern "C" __declspec(dllexport)
HRESULT MMCSGetChecksumInfo(DWORD dwIndex, MMCHECKSUMINFO* pCSInfoStruct)
{
    HRESULT hr = S_OK;

    // Clear the last error text
    g_strLastError[0] = '\0';

    if ( !pCSInfoStruct )
    {
        hr = E_INVALIDARG;
        goto Exit;
    }

    if ( pCSInfoStruct->cbStructSize != sizeof(MMCHECKSUMINFO) )
    {
        hr = HRESULT_FROM_WIN32(ERROR_PRODUCT_VERSION);
        goto Exit;
    }

    //
    // Return info about the checksum
    //
    switch ( dwIndex )
    {
    case CHECKSUM_SAMPLE_SIMPLE:
        StringCchCopyA(pCSInfoStruct->strName, ARRAYSIZE(pCSInfoStruct->strName),
            "Simple sum of data.");
        StringCchCopyA(pCSInfoStruct->strDesc, ARRAYSIZE(pCSInfoStruct->strDesc),
            "Sums the data in the range specified, stores in the size and location specified.");
        StringCchCopyA(pCSInfoStruct->strVersion, ARRAYSIZE(pCSInfoStruct->strVersion),
            "SUM1.0");
        // No specific data size expected
        pCSInfoStruct->cbExpectedDataSize = 0;
        break;

    case CHECKSUM_SAMPLE_COMPLEX:
        StringCchCopyA(pCSInfoStruct->strName, ARRAYSIZE(pCSInfoStruct->strName),
            "Complex Checksum Calculation");
        StringCchCopyA(pCSInfoStruct->strDesc, ARRAYSIZE(pCSInfoStruct->strDesc),
            "Does pre-determined work, storing at pre-determined location. Most parameters ignored.");
        StringCchCopyA(pCSInfoStruct->strVersion, ARRAYSIZE(pCSInfoStruct->strVersion),
            "COMPLEX1.0");
        // Data must be 16KB in size
        pCSInfoStruct->cbExpectedDataSize = 16 * 1024;
        break;

    default:
        hr = HRESULT_FROM_WIN32(ERROR_INVALID_INDEX);
        break;
    }

Exit:
    return hr;
}



//---------------------------------------------------------------------------------------
// Func: MMCSCalculateChecksum (Exported)
// Desc: The application will call this function to calculate a checksum. The structure
//       passed in gives the plug-in all of the info necessary to do the work, including 
//       the index of the checksum calculation to use. Note that some of the info can be
//       ignored by the plug-in if it isn't needed. More complex checksum calculations,
//       for instance, may not use some of the information passed in.
//---------------------------------------------------------------------------------------
extern "C" __declspec(dllexport)
HRESULT MMCSCalculateChecksum(MMCHECKSUMCALC* pCalcInfo)
{
    HRESULT hr = S_OK;

    // Clear the last error text
    g_strLastError[0] = '\0';

    if ( !pCalcInfo )
    {
        hr = E_INVALIDARG;
        goto Exit;
    }

    if ( pCalcInfo->cbStructSize != sizeof(MMCHECKSUMCALC) )
    {
        hr = HRESULT_FROM_WIN32(ERROR_PRODUCT_VERSION);
        goto Exit;
    }

    // Verify that we have data to work on
    if ( !pCalcInfo->pBaseData || !pCalcInfo->cbBaseData )
    {
        hr = E_INVALIDARG;
        goto Exit;
    }

    //
    // Calculate and store the checksum. The caller tells us which 
    // checksum calculator to use.
    //
    switch ( pCalcInfo->dwChecksumIndex )
    {
    case CHECKSUM_SAMPLE_SIMPLE:
        {
            DWORD dwChecksum = 0;

            // Simply add up each element. In this example we ignore type flags and element size,
            // but we mind the addresses and store size.
            if ( pCalcInfo->dwRegionEndAddress < pCalcInfo->cbBaseData )
            {
                for ( UINT ui = pCalcInfo->dwRegionStartAddress; ui <= pCalcInfo->dwRegionEndAddress; ui++ )
                    dwChecksum += pCalcInfo->pBaseData[ui];

                // Store it where we're told to, and truncate it to the size specified
                if ( pCalcInfo->cbBaseData >= (pCalcInfo->dwStoreAddress + (pCalcInfo->dwStoreSizeBits / 8) - 1) )
                {
                    switch ( pCalcInfo->dwStoreSizeBits )
                    {
                    case 8:
                        pCalcInfo->pBaseData[pCalcInfo->dwStoreAddress] = (BYTE)dwChecksum;
                        break;
                    case 16:
                        *(WORD*)&pCalcInfo->pBaseData[pCalcInfo->dwStoreAddress] = (WORD)dwChecksum;
                        break;
                    case 32:
                        *(DWORD*)&pCalcInfo->pBaseData[pCalcInfo->dwStoreAddress] = dwChecksum;
                        break;
                    }
                }
                else
                {
                    hr = HRESULT_FROM_WIN32(ERROR_INCORRECT_ADDRESS);
                    StringCchCopyA(g_strLastError, ARRAYSIZE(g_strLastError),
                        "Checksum store address is beyond data size");
                }
            }
            else
            {
                hr = HRESULT_FROM_WIN32(ERROR_INCORRECT_ADDRESS);
                StringCchCopyA(g_strLastError, ARRAYSIZE(g_strLastError),
                    "Region end address is beyond data size");
            }
        }
        break;

    case CHECKSUM_SAMPLE_COMPLEX:
        {
            // More (but not very) complex checksum calculations may have all the data hard-coded
            // in the plug-in. In such cases, the parameters passed in may be ignored, and the plug-in
            // does all the work based on hard-coded parameters.

            // In this (fake) example, we'll sum the first half and store the result at the beginning
            // of the second half. Then we'll sum the second half and store the result at the end.
            if ( pCalcInfo->cbBaseData == (1024 * 16) )
            {
                DWORD dwChecksum = 0;

                // Part 1: Sum the first half, store as first byte of second half
                for ( UINT ui = 0; ui < 8192; ui++ )
                    dwChecksum += pCalcInfo->pBaseData[ui];
                pCalcInfo->pBaseData[8192] = (BYTE)dwChecksum;

                // Part 2: Sum the second half, except the last byte, and store in last byte
                dwChecksum = 0;
                for ( UINT ui = 8192; ui < 16383; ui++ )
                    dwChecksum += pCalcInfo->pBaseData[ui];
                pCalcInfo->pBaseData[16383] = (BYTE)dwChecksum;

            }
            else
            {
                hr = HRESULT_FROM_WIN32(ERROR_INCORRECT_SIZE);
                StringCchCopyA(g_strLastError, ARRAYSIZE(g_strLastError),
                    "Expected data size is 16KB");
            }
        }
        break;

    default:
        hr = HRESULT_FROM_WIN32(ERROR_INVALID_INDEX);
        StringCchCopyA(g_strLastError, ARRAYSIZE(g_strLastError),
            "Invalid Checksum Index");
        break;
    }

Exit:
    return hr;
}

//---------------------------------------------------------------------------------------
// Func: MMCSGetLastErrorMessage (Exported)
// Desc: When an error occurs in the plug-in, the plug-in can format a user friendly 
//       error string. The application may request this string to give the user more
//       information on what went wrong. It generally only makes sense to format an 
//       error string for failures that are a result of the definition author or
//       end user.
//---------------------------------------------------------------------------------------
extern "C" __declspec(dllexport)
HRESULT MMCSGetLastErrorMessage(CHAR* strTextOut, DWORD cchTextOut)
{
    HRESULT hr = S_OK;
    StringCchCopyA(strTextOut, cchTextOut, g_strLastError);
    return hr;
}